// Data wrapper for PE/NE/LX format test files
// Includes all test data arrays with proper headers

#include <cstddef>

namespace data {
    // Forward declarations - NE format
    extern size_t progman_len;
    extern unsigned char progman[];

    extern size_t cga40woa_fon_len;
    extern unsigned char cga40woa_fon[];

    // Forward declarations - PE format
    extern size_t tcmadm64_len;
    extern unsigned char tcmadm64[];

    extern size_t tcmdx32_len;
    extern unsigned char tcmdx32[];

    // Forward declarations - LX format (OS/2)
    extern size_t strace_lx_len;
    extern unsigned char strace_lx[];

    extern size_t cmd_lx_len;
    extern unsigned char cmd_lx[];

    extern size_t sevenz_lx_len;
    extern unsigned char sevenz_lx[];

    // Forward declarations - LE format (DOS extenders)
    extern size_t doom_le_len;
    extern unsigned char doom_le[];

    // Forward declarations - LX with resources (OS/2)
    extern size_t makeini_lx_len;
    extern unsigned char makeini_lx[];

    extern size_t os2chess_lx_len;
    extern unsigned char os2chess_lx[];

    // Forward declarations - NE OS/2 format
    extern size_t sysfont_ne_len;
    extern unsigned char sysfont_ne[];
}

// Include test data implementations
#include "testdata/ne/progman.cc"
#include "testdata/ne/cga40woa_fon.cc"
#include "testdata/pe/tcmadm64.cc"
#include "testdata/pe/tcmdx32.cc"
#include "testdata/le/strace_lx.cc"
#include "testdata/le/cmd_lx.cc"
#include "testdata/le/7z_lx.cc"
#include "testdata/le/doom_le.cc"
#include "testdata/le/makeini_lx.cc"
#include "testdata/le/os2chess_lx.cc"
#include "testdata/ne/sysfont_ne.cc"
